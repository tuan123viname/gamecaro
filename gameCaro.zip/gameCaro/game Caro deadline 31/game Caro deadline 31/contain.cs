﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace game_Caro_deadline_31
{
    public class contain
    {
       public static int chessBoardWidth = 30;
        public static int chessBoardHeight = 30;
        public static int btnWidth = 30;
        public static int btnHeight = 30;
       
    }
}
